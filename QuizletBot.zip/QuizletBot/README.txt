Thank you for downloading QuizletBot!
To use QuizletBot:

1. Open up Command Prompt (Windows) or Terminal (Mac / Linux)
2. Type in: 'java -jar [LOCATION OF QUIZLETBOT.JAR]'
	(Tip: If you're not sure of the location, simply drag QuizletBot.jar into the command
	window after typing 'java -jar ' :)
3. Type a term, and QuizletBot will search for it! To exit the program, type 'exit' :)
4. Enjoy!

 - Ori Yonay
 
 
 Check out my GitHub / Instagram / Soundcloud:
 https://github.com/oriyonay
 https://instagram.com/pixxelofficial
 https://soundcloud.com/pixxelofficial